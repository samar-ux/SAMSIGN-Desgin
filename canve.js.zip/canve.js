$(document).on("click","#circle",function(){
      var randomStringb = randomString();
    $(".preview").append(`
    <di style="position:absolute">
    <div data-id="0" data-type="shape" layer-type="shape" layer-target="target${randomStringb}" class=" resize-drag  shape border border-gray-800 rounded rounded-full relative " style="border-width: 5px;border-color:#fff;width:90px;height:90px!important;">
                                   
                                    
    </div>
    </di>
    `);
   	 SaveCacheDateToLayer("target"+randomStringb,"shape",zindex);
    zindex++;
});

$(document).on("click","#Square-rtotat",function(){
     var randomStringb = randomString();
    $(".preview").append(`
    <div style="position:absolute">
    <div data-id="0" data-type="shape"  layer-type="shape" layer-target="target${randomStringb}" class="resize-drag  shape border border-gray-800 rounded rounded-xl" style="border-width: 5px;
    border-color: rgb(255, 255, 255);
    width: 91px;
    rotate: 45deg;
    height: 91px;
    
    z-index: 1000;">
    
    </div>
    </div>
    `);
    
     SaveCacheDateToLayer("target"+randomStringb,"shape",zindex);
    zindex++;
});

$(document).on("click","#Square",function(){
     var randomStringb = randomString();
    $(".preview").append(`
    <div style="position:absolute">
    <div data-id="0" data-type="shape"   layer-type="shape" layer-target="target${randomStringb}" class=" resize-drag  shape border border-gray-800 rounded rounded-xl  resize-drag " style="border-width: 5px;border-color:#fff;width:60px;height:90px!important;     ">
  
    </div>
    </div>
    `);
     SaveCacheDateToLayer("target"+randomStringb,"shape",zindex);
    zindex++;
});

$(document).on("click","#hexagon",function(){
     var randomStringb = randomString();
    $(".preview").append(`
    <div style="position:absolute">
    <div data-id="0" data-type="shape"  layer-type="shape" layer-target="target${randomStringb}" class=" resize-drag  shape border border-gray-800 rounded rounded-xl  resize-drag " style="background-color:#000;border-width: 5px;border-color:#000;-webkit-clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 47% 100%, 0% 75%, 0% 25%);width: 139px!important;
    height: 138px;;
    clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);">
        </div>
    </div>
    `);
     SaveCacheDateToLayer("target"+randomStringb,"shape",zindex);
    zindex++;
});

$(document).on("click","#rectangular",function(){
     var randomStringb = randomString();
    $(".preview").append(`
    <div style="position:absolute">
    <div data-id="0" data-type="shape"  layer-type="shape" layer-target="target${randomStringb}" class=" resize-drag  shape border border-gray-800 rounded rounded-xl  resize-drag " style="border-width: 5px;border-color:#fff;width:90px;height:45px!important">
    
    </div>
    </div>
    `);
     SaveCacheDateToLayer("target"+randomStringb,"shape",zindex);
    zindex++;
});

$(document).on("click","#shape-right",function(){
     var randomStringb = randomString();
    $(".preview").append(`
    <div style="position:absolute">
    <div data-id="0" data-type="shape"  layer-type="shape" layer-target="target${randomStringb}" class=" resize-drag  shape border border-gray-800 rounded rounded-xl  resize-drag " style="border-width: 5px;border-color:#fff;width:120px;height:120px!important;-webkit-clip-path: polygon(0 51%, 61% 53%, 60% 40%, 77% 61%, 59% 81%, 59% 66%, 0 65%);clip-path: polygon(0 51%, 61% 53%, 60% 40%, 77% 61%, 59% 81%, 59% 66%, 0 65%);">
    
    </div>
    </div>
    `);
     SaveCacheDateToLayer("target"+randomStringb,"shape",zindex);
    zindex++;
});

// Other Shape

$(document).on("click","#shape-left",function(){
     var randomStringb = randomString();
    $(".preview").append(`
    <div style="position:absolute">
        <div data-id="0" data-type="shape"  layer-type="shape" layer-target="target${randomStringb}" class=" resize-drag  shape border border-gray-800 rounded rounded-xl  resize-drag " style="border-width: 5px;border-color:#fff;width:120px;height:120px!important;-webkit-clip-path: polygon(12% 16%, 13% 27%, 100% 27%, 100% 37%, 13% 36%, 11% 46%, 1% 31%);clip-path: polygon(12% 16%, 13% 27%, 100% 27%, 100% 37%, 13% 36%, 11% 46%, 1% 31%);">
        
        </div>
    </div>
    `);
     SaveCacheDateToLayer("target"+randomStringb,"shape",zindex);
    zindex++;
});

// $(document).on("click","#rectangular",function(){
//     $(".preview").append(`
//     <div>
//     <div data-id="0" data-type="shape" class="shape border border-gray-800 rounded rounded-xl  resize-drag " style="border-width: 5px;border-color:#fff;width:90px;height:45px!important">
    
//     </div>
//     </div>
//     `);
// });


// $(document).on("click","#rectangular",function(){
//     $(".preview").append(`
//     <div>
//     <div data-id="0" data-type="shape" class="shape border border-gray-800 rounded rounded-xl  resize-drag " style="border-width: 5px;border-color:#fff;width:90px;height:45px!important">
    
//     </div>
//     </div>
//     `);
// });


// $(document).on("click","#rectangular",function(){
//     $(".preview").append(`
//     <div>
//     <div data-id="0" data-type="shape" class="shape border border-gray-800 rounded rounded-xl  resize-drag " style="border-width: 5px;border-color:#fff;width:90px;height:45px!important">
    
//     </div>
//     </div>
//     `);
// });